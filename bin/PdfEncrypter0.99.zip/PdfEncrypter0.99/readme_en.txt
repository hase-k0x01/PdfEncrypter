# PdfEncrypter Ver 0.99

# Copyrignt
Copyright(C) hase-k0x01. 2023.
���:   hase-k0x01
E-mail: hase-k0x01@rozen-meiden.com
Github: https://github.com/hase-k0x01


# 
This software encrypts PDF files.

You can set a password for encryption and set printing and accessibility options.

This software supports these PDF options below...

 - User Password
 - Owner Password
 - Permit Accessibility Extract Content
 - Permit Annotations
 - Permit Assemble Document
 - Permit Extract Content
 - Permit Modify Document
 - Permit Forms Fill
 - Permit Full Quality Print
 - Permit Print

# How to use this software
1. After starting this software, click the ... button next to the "Source PDF File Name" input field and select a PDF file. You can also drop PDF files from Explorer.
2. Enter the file name of encrypted PDF in the "Destination PDF File Name" input field.
3. Enter the password in the "User Password" and "Owner Password" fields. If "User Password" is set, a password will be required when opening the PDF file. If you set "Owner Password", you will be prompted for the password when trying to modify the PDF file. If you leave "User Password" blank, anyone can open the PDF file.
4. Select the options you want to enable by checking or unchecking the "Encrypt Options" checkbox.
5. Select the encryption strength from "Encryption Strength".
6. Press the "Encrypt" button to encrypt the PDF then PDF file.


# Software Terms of Use
Before using this software, please check the following items. You may use this software only if you agree to these terms.

This software is free software, so no usage fee is required.
The author is not responsible for any damages resulting from using this software. Also, even if this software has a bug and/or a fault, the author does NOT have any obligation to correct it or explain it.

In addition to the above, please refer to license.txt and accept its contents.


